#install.packages('readxl')
library(readxl)
library(readr)
View(exemplo1)

#install.packages("descr")
library(descr)

cdata <- exemplo1

# Ajustar categorias da variável resposta e depois verificar comportamento:
cdata$situacao<-as.factor(ifelse(cdata$situacao == 1, "Bom", "Ruim"))


# Medidas descritivas para idade:
mean(cdata$A13_idade)
sd(cdata$A13_idade)
median(cdata$A13_idade)

#Histograma 
hist(cdata$A13_idade,nclass=20)

#frequencias
freq(cdata$A9_sexo)

# Avaliando relação de uma variável qualitativa com a variável resposta binária:
x <- xtabs(~ situacao+ A15_tipo_resid, data = cdata)
cols <- c("#660d32", "#bc1a5e")


# Barras empilhadas.
barplot(x,
        beside = FALSE,
        xlab = "Tipo de residencia",
        ylab = "Frequência absoluta",
        col = cols)
legend("topleft",
       legend = levels(cdata$bom_ruim_21),
       fill = cols,
       bty = "n")
box(bty = "L")

# Cria tabela com as proporções
u <- x %*% diag(1/colSums(x))
colnames(u) <- colnames(x)
u

# Barras empilhadas de proporções
barplot(u,
        beside = FALSE,
        xlab = "Tipo de residencia",
        ylab = "Frequência relativa",
        col = cols)
legend("topleft",
       inset = c(0.025, -0.12),
       xpd = TRUE,
       ncol = 2,
       legend = levels(cdata$bom_ruim_21),
       fill = cols,
       bty = "n")
box(bty = "L")



# Avaliando relação de uma variável quantitativa com a variável resposta binária:

#Tabela + Gráfico boxplot categorizado:
box_rm <- compmeans(cdata$A13_idade, cdata$situacao)
box_rm
plot(box_rm, ylab = "Idade", xlab = "Situacao do Pagador")


